import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string;
  change: string;
  changeType: "up" | "down" | "neutral";
  icon: LucideIcon;
  delay?: number;
}

export function StatCard({ title, value, change, changeType, icon: Icon, delay = 0 }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay, ease: [0.4, 0, 0.2, 1] }}
      className="bg-card rounded-lg shadow-card p-4 hover:shadow-card-hover transition-shadow duration-200"
    >
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{title}</span>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="text-2xl font-semibold font-mono-data">{value}</div>
      <p className="text-xs mt-1">
        <span
          className={
            changeType === "up"
              ? "text-danger"
              : changeType === "down"
              ? "text-success"
              : "text-muted-foreground"
          }
        >
          {change}
        </span>
        <span className="text-muted-foreground ml-1">vs last 24h</span>
      </p>
    </motion.div>
  );
}
