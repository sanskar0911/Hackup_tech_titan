import { Bell, Moon, Sun, Search } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { useState } from "react";

export function TopNav() {
  const { theme, toggle } = useTheme();
  const [alertCount] = useState(6);

  return (
    <header className="h-14 sticky top-0 z-30 flex items-center justify-between px-6 border-b border-border bg-card/80 backdrop-blur-md">
      <div className="flex items-center gap-3 flex-1 max-w-md">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search account ID, transaction..."
          className="flex-1 bg-transparent text-sm placeholder:text-muted-foreground outline-none"
        />
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={toggle}
          className="h-8 w-8 flex items-center justify-center rounded-md hover:bg-accent transition-colors"
        >
          {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>

        <button className="h-8 w-8 flex items-center justify-center rounded-md hover:bg-accent transition-colors relative">
          <Bell className="h-4 w-4" />
          {alertCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-danger text-danger-foreground text-[10px] font-bold flex items-center justify-center">
              {alertCount}
            </span>
          )}
        </button>

        <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary ml-1">
          JD
        </div>
      </div>
    </header>
  );
}
