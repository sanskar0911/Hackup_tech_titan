export const transactionOverTime = [
  { date: "Jan", total: 4200, suspicious: 120 },
  { date: "Feb", total: 3800, suspicious: 98 },
  { date: "Mar", total: 5100, suspicious: 210 },
  { date: "Apr", total: 4700, suspicious: 175 },
  { date: "May", total: 5600, suspicious: 340 },
  { date: "Jun", total: 6200, suspicious: 280 },
  { date: "Jul", total: 5900, suspicious: 195 },
];

export const riskDistribution = [
  { range: "0-10", count: 3400 },
  { range: "11-20", count: 2800 },
  { range: "21-30", count: 1900 },
  { range: "31-40", count: 1200 },
  { range: "41-50", count: 800 },
  { range: "51-60", count: 450 },
  { range: "61-70", count: 280 },
  { range: "71-80", count: 120 },
  { range: "81-90", count: 45 },
  { range: "91-100", count: 12 },
];

export const fraudBreakdown = [
  { name: "Normal", value: 94.2, fill: "hsl(var(--success))" },
  { name: "Suspicious", value: 4.1, fill: "hsl(var(--warning))" },
  { name: "Fraudulent", value: 1.7, fill: "hsl(var(--danger))" },
];

export const alerts = [
  { id: "ALT-001", type: "Circular Transaction", account: "ACC-8842", amount: "$12,400.00", risk: 98, time: "2m ago", status: "open" as const },
  { id: "ALT-002", type: "Rapid Transfer", account: "ACC-3371", amount: "$45,200.00", risk: 92, time: "5m ago", status: "open" as const },
  { id: "ALT-003", type: "Structuring", account: "ACC-1209", amount: "$9,800.00", risk: 87, time: "12m ago", status: "investigating" as const },
  { id: "ALT-004", type: "Velocity Anomaly", account: "ACC-5567", amount: "$28,900.00", risk: 85, time: "18m ago", status: "investigating" as const },
  { id: "ALT-005", type: "Circular Transaction", account: "ACC-7723", amount: "$67,100.00", risk: 79, time: "25m ago", status: "open" as const },
  { id: "ALT-006", type: "Shell Company Link", account: "ACC-9901", amount: "$134,500.00", risk: 95, time: "32m ago", status: "open" as const },
  { id: "ALT-007", type: "Rapid Transfer", account: "ACC-2244", amount: "$8,200.00", risk: 72, time: "45m ago", status: "resolved" as const },
  { id: "ALT-008", type: "Geographic Anomaly", account: "ACC-6688", amount: "$19,700.00", risk: 68, time: "1h ago", status: "investigating" as const },
  { id: "ALT-009", type: "Structuring", account: "ACC-4455", amount: "$9,500.00", risk: 61, time: "2h ago", status: "resolved" as const },
  { id: "ALT-010", type: "Layering", account: "ACC-1133", amount: "$87,300.00", risk: 91, time: "3h ago", status: "open" as const },
];

export const transactions = [
  { id: "TXN-20241", from: "ACC-8842", to: "ACC-3371", amount: "$12,400.00", risk: 98, time: "2024-01-15 14:32:11", type: "Wire Transfer" },
  { id: "TXN-20242", from: "ACC-3371", to: "ACC-1209", amount: "$11,800.00", risk: 87, time: "2024-01-15 14:35:22", type: "Wire Transfer" },
  { id: "TXN-20243", from: "ACC-1209", to: "ACC-8842", amount: "$11,200.00", risk: 92, time: "2024-01-15 14:38:45", type: "Wire Transfer" },
  { id: "TXN-20244", from: "ACC-5567", to: "ACC-7723", amount: "$28,900.00", risk: 85, time: "2024-01-15 15:01:33", type: "ACH" },
  { id: "TXN-20245", from: "ACC-9901", to: "ACC-2244", amount: "$45,200.00", risk: 72, time: "2024-01-15 15:12:08", type: "Wire Transfer" },
  { id: "TXN-20246", from: "ACC-6688", to: "ACC-4455", amount: "$8,200.00", risk: 45, time: "2024-01-15 15:28:19", type: "ACH" },
  { id: "TXN-20247", from: "ACC-1133", to: "ACC-9901", amount: "$87,300.00", risk: 91, time: "2024-01-15 15:45:02", type: "Wire Transfer" },
  { id: "TXN-20248", from: "ACC-2244", to: "ACC-6688", amount: "$19,700.00", risk: 34, time: "2024-01-15 16:02:44", type: "ACH" },
];

export const flowNodes = [
  { id: "ACC-8842", label: "ACC-8842", risk: 98, type: "individual", balance: "$234,100" },
  { id: "ACC-3371", label: "ACC-3371", risk: 72, type: "business", balance: "$1,205,400" },
  { id: "ACC-1209", label: "ACC-1209", risk: 87, type: "individual", balance: "$45,200" },
  { id: "ACC-5567", label: "ACC-5567", risk: 45, type: "business", balance: "$890,000" },
  { id: "ACC-7723", label: "ACC-7723", risk: 79, type: "shell", balance: "$12,100" },
  { id: "ACC-9901", label: "ACC-9901", risk: 95, type: "shell", balance: "$2,340,000" },
  { id: "ACC-2244", label: "ACC-2244", risk: 32, type: "individual", balance: "$67,800" },
  { id: "ACC-6688", label: "ACC-6688", risk: 68, type: "business", balance: "$445,200" },
];

export const flowEdges = [
  { source: "ACC-8842", target: "ACC-3371", amount: "$12,400", animated: true },
  { source: "ACC-3371", target: "ACC-1209", amount: "$11,800", animated: true },
  { source: "ACC-1209", target: "ACC-8842", amount: "$11,200", animated: true },
  { source: "ACC-5567", target: "ACC-7723", amount: "$28,900", animated: false },
  { source: "ACC-9901", target: "ACC-3371", amount: "$45,200", animated: true },
  { source: "ACC-6688", target: "ACC-2244", amount: "$8,200", animated: false },
  { source: "ACC-7723", target: "ACC-9901", amount: "$67,100", animated: true },
];

export function getRiskColor(risk: number): string {
  if (risk >= 80) return "hsl(var(--danger))";
  if (risk >= 50) return "hsl(var(--warning))";
  return "hsl(var(--success))";
}

export function getRiskLabel(risk: number): string {
  if (risk >= 80) return "High";
  if (risk >= 50) return "Medium";
  return "Low";
}
