import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, ArrowRight, AlertTriangle, Globe, Zap, Clock } from "lucide-react";
import { transactions, getRiskColor, getRiskLabel } from "@/lib/mock-data";

const riskBreakdown = [
  { level: "High", label: "Rapid Transfer (Velocity: 4.2tx/min)", icon: Zap, risk: 92 },
  { level: "High", label: "Circular Fund Flow Detected", icon: AlertTriangle, risk: 98 },
  { level: "Medium", label: "New IP Geolocation (Seychelles)", icon: Globe, risk: 65 },
  { level: "Medium", label: "After-Hours Activity Pattern", icon: Clock, risk: 58 },
];

export default function Investigation() {
  const [accountId, setAccountId] = useState("");
  const [tracing, setTracing] = useState(false);
  const [results, setResults] = useState(false);

  const handleTrace = () => {
    if (!accountId) return;
    setTracing(true);
    setTimeout(() => {
      setTracing(false);
      setResults(true);
    }, 1500);
  };

  const relatedTx = transactions.filter((tx) => tx.from.includes("8842") || tx.to.includes("8842"));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Investigation Mode</h1>
        <p className="text-sm text-muted-foreground">Trace fund flows and analyze risk patterns</p>
      </div>

      <div className="bg-card rounded-lg shadow-card p-6">
        <div className="flex items-center gap-3 max-w-xl">
          <div className="flex-1 flex items-center gap-2 bg-muted rounded-md px-3 py-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <input
              value={accountId}
              onChange={(e) => setAccountId(e.target.value)}
              placeholder="Enter Account ID (e.g. ACC-8842)"
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
          </div>
          <button
            onClick={handleTrace}
            disabled={tracing}
            className="px-4 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {tracing ? "Tracing..." : "Trace Fund Flow"}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {tracing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="bg-card rounded-lg shadow-card p-8 text-center"
          >
            <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
              <div className="h-4 w-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              Analyzing transaction chains for {accountId || "ACC-8842"}...
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {results && !tracing && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            {/* Transaction Chain */}
            <div className="bg-card rounded-lg shadow-card p-5">
              <h3 className="text-sm font-medium mb-4">Transaction Chain</h3>
              <div className="flex items-center gap-2 flex-wrap">
                {["ACC-8842", "ACC-3371", "ACC-1209", "ACC-8842"].map((acc, i, arr) => (
                  <div key={i} className="flex items-center gap-2">
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.15 }}
                      className="px-3 py-1.5 rounded-md bg-muted font-mono-data text-xs font-medium"
                    >
                      {acc}
                    </motion.div>
                    {i < arr.length - 1 && (
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                    )}
                  </div>
                ))}
                <span className="text-xs text-danger font-medium ml-2">⚠ Circular Flow</span>
              </div>
            </div>

            {/* Timeline */}
            <div className="bg-card rounded-lg shadow-card p-5">
              <h3 className="text-sm font-medium mb-4">Transaction Timeline</h3>
              <div className="space-y-3">
                {relatedTx.map((tx, i) => (
                  <motion.div
                    key={tx.id}
                    initial={{ opacity: 0, x: -16 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="flex items-center gap-4 text-xs"
                  >
                    <span className="font-mono-data text-muted-foreground w-36">{tx.time}</span>
                    <div className="h-2 w-2 rounded-full" style={{ backgroundColor: getRiskColor(tx.risk) }} />
                    <span className="font-mono-data">{tx.from}</span>
                    <ArrowRight className="h-3 w-3 text-muted-foreground" />
                    <span className="font-mono-data">{tx.to}</span>
                    <span className="font-mono-data font-medium">{tx.amount}</span>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Risk Breakdown */}
            <div className="bg-card rounded-lg shadow-card p-5">
              <h3 className="text-sm font-medium mb-4">Risk Breakdown</h3>
              <div className="space-y-2">
                {riskBreakdown.map((item, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 + i * 0.08 }}
                    className="flex items-center gap-3 p-3 bg-muted/50 rounded-md"
                  >
                    <item.icon className="h-4 w-4" style={{ color: getRiskColor(item.risk) }} />
                    <span
                      className="text-[10px] font-bold px-1.5 py-0.5 rounded uppercase"
                      style={{ color: getRiskColor(item.risk), backgroundColor: `${getRiskColor(item.risk)}15` }}
                    >
                      {getRiskLabel(item.risk)} Risk
                    </span>
                    <span className="text-xs">{item.label}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
