import { motion } from "framer-motion";

export default function SettingsPage() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-xl font-semibold">Settings</h1>
        <p className="text-sm text-muted-foreground">Configure system preferences</p>
      </div>

      <div className="bg-card rounded-lg shadow-card p-5 space-y-4">
        <h3 className="text-sm font-medium">Alert Thresholds</h3>
        {[
          { label: "High Risk Threshold", value: "80" },
          { label: "Medium Risk Threshold", value: "50" },
          { label: "Auto-flag Amount ($)", value: "10000" },
        ].map((s) => (
          <div key={s.label} className="flex items-center justify-between">
            <label className="text-sm text-muted-foreground">{s.label}</label>
            <input
              defaultValue={s.value}
              className="w-24 bg-muted rounded-md px-3 py-1.5 text-sm text-right font-mono-data outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
        ))}
      </div>

      <div className="bg-card rounded-lg shadow-card p-5 space-y-4">
        <h3 className="text-sm font-medium">Notifications</h3>
        {["Email alerts for high-risk flags", "Browser push notifications", "Daily digest report"].map((item) => (
          <label key={item} className="flex items-center justify-between cursor-pointer">
            <span className="text-sm text-muted-foreground">{item}</span>
            <div className="h-5 w-9 bg-primary rounded-full relative cursor-pointer">
              <div className="absolute right-0.5 top-0.5 h-4 w-4 bg-primary-foreground rounded-full transition-transform" />
            </div>
          </label>
        ))}
      </div>
    </motion.div>
  );
}
