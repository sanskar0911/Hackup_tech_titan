import { FileText, Download, Calendar } from "lucide-react";
import { motion } from "framer-motion";

const reports = [
  { id: "RPT-001", title: "Monthly AML Summary", date: "Jan 2024", accounts: 284, alerts: 47, status: "Ready" },
  { id: "RPT-002", title: "Circular Transaction Analysis", date: "Jan 2024", accounts: 12, alerts: 8, status: "Ready" },
  { id: "RPT-003", title: "High-Risk Account Report", date: "Jan 2024", accounts: 34, alerts: 22, status: "Ready" },
  { id: "RPT-004", title: "Geographic Anomaly Report", date: "Dec 2023", accounts: 19, alerts: 11, status: "Ready" },
  { id: "RPT-005", title: "Quarterly Compliance Review", date: "Q4 2023", accounts: 1240, alerts: 156, status: "Generating" },
];

export default function Reports() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Reports</h1>
        <p className="text-sm text-muted-foreground">Generate and download compliance reports</p>
      </div>

      <div className="space-y-3">
        {reports.map((report, i) => (
          <motion.div
            key={report.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
            className="flex items-center justify-between p-4 bg-card rounded-lg shadow-card"
          >
            <div className="flex items-center gap-4">
              <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">
                <FileText className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h4 className="text-sm font-medium">{report.title}</h4>
                <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{report.date}</span>
                  <span>{report.accounts} accounts</span>
                  <span>{report.alerts} alerts</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className={`text-[10px] uppercase font-medium px-2 py-0.5 rounded ${
                report.status === "Ready" ? "bg-success/10 text-success" : "bg-warning/10 text-warning"
              }`}>
                {report.status}
              </span>
              <button
                disabled={report.status !== "Ready"}
                className="h-8 w-8 flex items-center justify-center rounded-md hover:bg-accent transition-colors disabled:opacity-30"
              >
                <Download className="h-4 w-4" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
