import { transactions } from "@/lib/mock-data";
import { getRiskColor, getRiskLabel } from "@/lib/mock-data";
import { motion } from "framer-motion";

export default function Transactions() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Transactions</h1>
        <p className="text-sm text-muted-foreground">Showing 1–{transactions.length} of 1,240 transactions</p>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-card rounded-lg shadow-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">ID</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">From</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">To</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">Amount</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">Type</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">Risk</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">Time</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((tx, i) => (
                <motion.tr
                  key={tx.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="border-b border-border last:border-0 hover:bg-accent/50 transition-colors"
                >
                  <td className="px-4 py-3 font-mono-data text-xs">{tx.id}</td>
                  <td className="px-4 py-3 font-mono-data text-xs">{tx.from}</td>
                  <td className="px-4 py-3 font-mono-data text-xs">{tx.to}</td>
                  <td className="px-4 py-3 font-mono-data text-xs font-medium">{tx.amount}</td>
                  <td className="px-4 py-3 text-xs">{tx.type}</td>
                  <td className="px-4 py-3">
                    <span
                      className="text-xs font-bold px-2 py-0.5 rounded"
                      style={{
                        color: getRiskColor(tx.risk),
                        backgroundColor: `${getRiskColor(tx.risk)}15`,
                      }}
                    >
                      {tx.risk} {getRiskLabel(tx.risk)}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground font-mono-data">{tx.time}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
