import { useState } from "react";
import { alerts, getRiskColor, getRiskLabel } from "@/lib/mock-data";
import { motion } from "framer-motion";
import { Filter } from "lucide-react";

const riskFilters = ["All", "High", "Medium", "Low"] as const;
const statusFilters = ["All", "open", "investigating", "resolved"] as const;

export default function Alerts() {
  const [riskFilter, setRiskFilter] = useState<string>("All");
  const [statusFilter, setStatusFilter] = useState<string>("All");

  const filtered = alerts.filter((a) => {
    const riskMatch = riskFilter === "All" || getRiskLabel(a.risk) === riskFilter;
    const statusMatch = statusFilter === "All" || a.status === statusFilter;
    return riskMatch && statusMatch;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Fraud Alerts</h1>
        <p className="text-sm text-muted-foreground">{filtered.length} alerts matching filters</p>
      </div>

      <div className="flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <span className="text-xs text-muted-foreground">Risk:</span>
          {riskFilters.map((f) => (
            <button
              key={f}
              onClick={() => setRiskFilter(f)}
              className={`text-xs px-2.5 py-1 rounded-md transition-colors ${
                riskFilter === f ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Status:</span>
          {statusFilters.map((f) => (
            <button
              key={f}
              onClick={() => setStatusFilter(f)}
              className={`text-xs px-2.5 py-1 rounded-md transition-colors capitalize ${
                statusFilter === f ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-accent"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        {filtered.map((alert, i) => (
          <motion.div
            key={alert.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
            whileHover={{ y: -2 }}
            className="relative flex items-center justify-between p-4 bg-card rounded-lg shadow-card cursor-pointer"
          >
            <div className="flex items-center gap-4">
              <div
                className={`w-1.5 h-10 rounded-full ${alert.risk >= 90 ? "animate-pulse-risk" : ""}`}
                style={{ backgroundColor: getRiskColor(alert.risk) }}
              />
              <div>
                <h4 className="text-sm font-medium leading-none">{alert.type}</h4>
                <p className="text-xs text-muted-foreground mt-1 font-mono-data">
                  {alert.account} • {alert.amount}
                </p>
              </div>
            </div>
            <div className="text-right flex items-center gap-4">
              <span
                className={`text-[10px] uppercase px-2 py-0.5 rounded font-medium capitalize ${
                  alert.status === "open"
                    ? "bg-danger/10 text-danger"
                    : alert.status === "investigating"
                    ? "bg-warning/10 text-warning"
                    : "bg-success/10 text-success"
                }`}
              >
                {alert.status}
              </span>
              <div>
                <div
                  className="text-xs font-bold px-2 py-1 rounded"
                  style={{ color: getRiskColor(alert.risk), backgroundColor: `${getRiskColor(alert.risk)}15` }}
                >
                  {alert.risk} RISK
                </div>
                <p className="text-[10px] text-muted-foreground mt-1 uppercase tracking-wider">{alert.time}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
