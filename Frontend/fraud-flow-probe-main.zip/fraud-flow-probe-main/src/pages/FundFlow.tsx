import { useCallback, useState, useMemo } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  type Node,
  type Edge,
  Handle,
  Position,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { flowNodes, flowEdges, getRiskColor } from "@/lib/mock-data";
import { X, Shield, MapPin, Smartphone } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

function AccountNode({ data }: { data: any }) {
  const riskColor = getRiskColor(data.risk);
  return (
    <div className="bg-card rounded-lg shadow-card min-w-[160px] overflow-hidden">
      <Handle type="target" position={Position.Left} className="!bg-primary !w-2 !h-2" />
      <div className="h-1.5" style={{ backgroundColor: riskColor }} />
      <div className="p-3">
        <div className="flex items-center justify-between mb-1">
          <span className="font-mono-data text-xs font-medium">{data.label}</span>
          <span
            className="text-[10px] font-bold px-1.5 py-0.5 rounded"
            style={{ color: riskColor, backgroundColor: `${riskColor}15` }}
          >
            {data.risk}
          </span>
        </div>
        <div className="text-[10px] text-muted-foreground capitalize">{data.accountType}</div>
        <div className="text-xs font-mono-data mt-1">{data.balance}</div>
      </div>
      <Handle type="source" position={Position.Right} className="!bg-primary !w-2 !h-2" />
    </div>
  );
}

const nodeTypes = { account: AccountNode };

function buildNodes(): Node[] {
  const positions = [
    { x: 50, y: 50 }, { x: 300, y: 0 }, { x: 550, y: 100 },
    { x: 50, y: 250 }, { x: 300, y: 300 }, { x: 550, y: 280 },
    { x: 150, y: 450 }, { x: 450, y: 420 },
  ];
  return flowNodes.map((n, i) => ({
    id: n.id,
    type: "account",
    position: positions[i] || { x: i * 200, y: 100 },
    data: { label: n.label, risk: n.risk, accountType: n.type, balance: n.balance },
  }));
}

function buildEdges(): Edge[] {
  return flowEdges.map((e, i) => ({
    id: `e-${i}`,
    source: e.source,
    target: e.target,
    label: e.amount,
    animated: e.animated,
    type: "smoothstep",
    style: { stroke: e.animated ? "hsl(var(--danger))" : "hsl(var(--muted-foreground))", strokeWidth: 2 },
    labelStyle: { fontSize: 10, fontFamily: "JetBrains Mono" },
  }));
}

export default function FundFlow() {
  const [nodes, , onNodesChange] = useNodesState(buildNodes());
  const [edges, , onEdgesChange] = useEdgesState(buildEdges());
  const [selected, setSelected] = useState<any>(null);

  const onNodeClick = useCallback((_: any, node: Node) => {
    setSelected(node.data);
  }, []);

  return (
    <div className="space-y-4 h-[calc(100vh-7rem)]">
      <div>
        <h1 className="text-xl font-semibold">Fund Flow Graph</h1>
        <p className="text-sm text-muted-foreground">Interactive visualization of transaction flows</p>
      </div>

      <div className="relative flex-1 bg-card rounded-lg shadow-card overflow-hidden" style={{ height: "calc(100% - 60px)" }}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onNodeClick={onNodeClick}
          nodeTypes={nodeTypes}
          fitView
          className="!bg-background"
        >
          <Background gap={20} size={1} />
          <Controls className="!bg-card !border-border !shadow-card" />
          <MiniMap
            nodeColor={(n) => getRiskColor(Number(n.data?.risk ?? 0))}
            className="!bg-card !border-border"
          />
        </ReactFlow>

        <AnimatePresence>
          {selected && (
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="absolute top-0 right-0 h-full w-80 bg-card border-l border-border shadow-lg p-5 overflow-y-auto z-10"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-sm">Account Details</h3>
                <button onClick={() => setSelected(null)} className="text-muted-foreground hover:text-foreground">
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Account ID</label>
                  <p className="font-mono-data text-sm">{selected.label}</p>
                </div>
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Type</label>
                  <p className="text-sm capitalize">{selected.accountType}</p>
                </div>
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Balance</label>
                  <p className="font-mono-data text-sm">{selected.balance}</p>
                </div>
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Risk Score</label>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{ width: `${selected.risk}%`, backgroundColor: getRiskColor(selected.risk) }}
                      />
                    </div>
                    <span className="font-mono-data text-xs font-bold" style={{ color: getRiskColor(selected.risk) }}>
                      {selected.risk}
                    </span>
                  </div>
                </div>

                <div className="border-t border-border pt-4 space-y-3">
                  <h4 className="text-xs font-medium">KYC & Metadata</h4>
                  <div className="flex items-center gap-2 text-xs">
                    <Shield className="h-3.5 w-3.5 text-muted-foreground" />
                    <span>KYC Status: <strong className="text-warning">Pending</strong></span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <MapPin className="h-3.5 w-3.5 text-muted-foreground" />
                    <span>Last IP: 185.42.xx.xx (Seychelles)</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <Smartphone className="h-3.5 w-3.5 text-muted-foreground" />
                    <span>Linked Devices: 3</span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
